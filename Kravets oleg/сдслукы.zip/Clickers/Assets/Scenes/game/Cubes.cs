﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cubes : MonoBehaviour
{
    public GameObject[] cubes = new GameObject[108];
    public Color[] randomColors;
    void Start()
    {
        for(int c = 1; c < cubes.Length + 1; c++)
        {
            cubes[c - 1] = GameObject.Find("Cube (" + c + ")");
        }
        foreach(GameObject cube in cubes)
        {
            cube.GetComponent<MeshRenderer>().material.color = randomColors[Random.Range(0, randomColors.Length - 1)];
        }
    }

    void Update()
    {
        
    }
}
